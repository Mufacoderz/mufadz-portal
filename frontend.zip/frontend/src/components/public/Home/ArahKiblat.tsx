const ArahKiblat = () => {
    return (
        <div>
            araha kiblat
        </div>
    )
}

export default ArahKiblat
