
import MainHero from '../../components/public/Home/Home'
import Footer from '../../components/public/Footer'

const Homepages = () => {
    return (
        <div >
            
            <MainHero/>
            <Footer/>
        </div>
    )
}

export default Homepages
